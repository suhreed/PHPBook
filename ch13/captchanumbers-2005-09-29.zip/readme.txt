GD2 Problems
------------
You must have GD2 module installed with PHP.
If u get imagecreate() not found, it's means you don't have GD2 installed.

You can install it easly on windows by open php.ini and uncomment extension=php_gd2.dll line. Also check that extension_dir in php.ini is correct.

Font Problems
-------------
You must have arial.ttf available for the script to work.

If the picture is shown without numbers (only grid) u need to download
arial.ttf from http://www.webpagepublicity.com/free-fonts-a4.html.

Save arial.ttf in the same directory of the script. Notice it's arial.ttf
and not Arial.ttf.



